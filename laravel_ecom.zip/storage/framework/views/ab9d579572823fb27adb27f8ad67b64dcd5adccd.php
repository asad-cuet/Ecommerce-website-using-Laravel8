<?php $__env->startSection('content'); ?>
<div class="container py-3">
    <div class="row">
        <div class="col-md-4" style="text-align:center;">
             <img src="<?php echo e(asset('assets/image/img_avatar3.png')); ?>" width="50%" alt="Avater">
        </div>
        <div class="col-md-8">
            <p><b>Name:</b><?php echo e(Auth::user()->name); ?></p>
            <p><b>Email:</b><?php echo e(Auth::user()->email); ?></p>
            <p><b>Phone:</b><?php echo e(Auth::user()->phone); ?></p>
            <p><b>Address:</b><?php echo e(Auth::user()->address1); ?></p>
            <p><b>Zip Code:</b><?php echo e(Auth::user()->pincode); ?></p>
        </div>
    </div>
        

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\resources\views/profile.blade.php ENDPATH**/ ?>