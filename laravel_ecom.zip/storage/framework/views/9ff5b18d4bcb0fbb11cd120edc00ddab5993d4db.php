<div class="pt-5 text-white navbar-dark bg-dark">
      <?php 
      $desc=App\Models\Setting::first()->footer_descript;
      echo html_entity_decode($desc);
      ?>
</div>

<?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\resources\views/layouts/front_inc/footer.blade.php ENDPATH**/ ?>