                                     <!-- showing main component  -->
   
<?php $__env->startSection('title'); ?><?php echo e($category->name); ?><?php $__env->stopSection(); ?>


<?php $__env->startSection('meta'); ?>
<meta name="title" content="<?php echo e($category->meta_title); ?>">
<meta name="description" content="<?php echo e($category->meta_descript); ?>">
<meta name="keywords" content="<?php echo e($category->meta_keywords); ?>">    
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="py-3 mb-4 shadow-sm bg-warning border-top">
      <div class="container">
            <h6 class="mb-0">Collections / <?php echo e($category->name); ?></h6>      
      </div>       
</div>   

<div class="py-5">
      <div class="container">
            <div class="row">
                  <h2><?php echo e($category->name); ?></h2>
                 
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="col-md-3 mb-3">
                                    <div class="card">
                                    <a href="<?php echo e(url('category/'.$item->category->slug.'/'.$item->slug)); ?>">
                                    
                                          <img src="<?php echo e(asset('assets/uploads/product/'.$item->image)); ?>" alt="Product Image" class="w-100">
                                          <div class="card-body">
                                                <h5><?php echo e($item->name); ?></h5>
                                                <span class="float-start"><?php echo e($item->selling_price); ?></span>
                                                <span class="float-end"><s><?php echo e($item->original_price); ?></s></span>
                                          </div>
                                    
                                    </a>   
                                    </div>   

                              </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
            </div>
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
      $('.featured-carousel').owlCarousel({
            loop:true,
            margin:10,
            autoplay:true,
           autoplayTimeout:1500,
            autoplayHoverPause:true,
            responsiveClass:true,
            responsive:{
            0:{
                  items:2,
                  nav:true
            },
            600:{
                  items:4,
                  nav:false
            },
            1000:{
                  items:7,
                  nav:true,
                  loop:true
            }
            }
      })

 </script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\resources\views/frontend/view-category.blade.php ENDPATH**/ ?>