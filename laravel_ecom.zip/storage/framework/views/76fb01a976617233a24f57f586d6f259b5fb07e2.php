

<?php $__env->startSection('title','Write a Review'); ?>
    
<?php $__env->startSection('content'); ?>
    
<div class="container py-5">
      <div class="row">
            <div class="col-md-12">
                  <div class="card">
                        <div class="card-body">
                              <?php if($verified_purchase->count()>0): ?>
                                   <h5>You are writing a review for <?php echo e($product->name); ?></h5>
                                   <form action="<?php echo e(url('/add-review')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                         <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                         <textarea name="user_review" cols="30" rows="10" class="form-control" placeholder="Write a review"></textarea>
                                         <button type="submit" class="btn btn-primary mt-3">Submit Review</button>

                                   </form>
                              <?php else: ?>
                                   <div class="alert alert-danger">
                                         <h5>You are not eligible to review this Product</h5>
                                         <p>
                                               For the trustworthiness of the reviews,only customers who purchased
                                               the product can write a review about the product.
                                         </p>
                                         <a href="<?php echo e(url('/')); ?>" class="btn btn-primary mt-3">Go to home page</a>
                                   </div>

                              <?php endif; ?>
                        </div>
                  </div>
            </div>
      </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\resources\views/frontend/review/index.blade.php ENDPATH**/ ?>