                                     <!-- showing main component  -->
             
<?php $__env->startSection('content'); ?>
<div class="card">
      <div class="card-body">

      <form method="POST" action="<?php echo e(url('products/update/'.$val->id)); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> 
            <div class="row">
            <div class="col-md-12 mb-3">
                  <select class="form-select form-control border" name="cate_id">
                        <option>Select a category</option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if($item->id==$val->category->id) echo'selected'; ?>><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
            </div>      
                      
            <div class="col-md-6 mb-3">
                  <label for="">Name</label>
                  <input type="text" id="name" class="form-control" name="name" value="<?php echo e($val->name); ?>">
            </div>            
            <div class="col-md-6 mb-3">
                  <label for="">Slug</label>
                  <input type="text" id="slug" class="form-control" name="slug" value="<?php echo e($val->slug); ?>">
            </div>            


            <script>   
                  $('#name').keyup(function()   //click
                  {
                  var name=$('#name').val();
                  name=name.replace(/\s+/g, '-');
                  $('#slug').val(name);
                  });
            </script>


            <div class="col-md-12 mb-3">
                  <label for="">Small Description</label>
                  <textarea id="myMce" class="form-control" name="small_description"><?php echo e($val->small_description); ?></textarea>
            </div> 
            <div class="col-md-12 mb-3">
                  <label for="">Description</label>
                  <textarea id="myMce" class="form-control" name="description"><?php echo e($val->description); ?></textarea>
            </div> 
            
            <div class="col-md-6 mb-3">
                  <label for="">Original Price</label>
                  <input type="number" name="original_price" class="form-control" value="<?php echo e($val->original_price); ?>">
            </div>  
            <div class="col-md-6 mb-3">
                  <label for="">Selling Price</label>
                  <input type="number" name="selling_price" class="form-control" value="<?php echo e($val->selling_price); ?>">
            </div>  
            <div class="col-md-6 mb-3">
                  <label for="">Quantity</label>
                  <input type="number" name="qty" class="form-control" value="<?php echo e($val->qty); ?>">
            </div>  
            <div class="col-md-6 mb-3">
                  <label for="">Tax</label>
                  <input type="number" name="tax" class="form-control" value="<?php echo e($val->tax); ?>">
            </div>  
            <div class="col-md-6 mb-3">
                  <label for="">Active</label>  
                  <input type="checkbox" name="status" <?php if($val->status==1) echo"checked"  ?>>
            </div>  
            <div class="col-md-6 mb-3">
                  <label for="">Trending</label>
                  <input type="checkbox" name="trending" <?php if($val->trending==1) echo"checked"  ?>>
            </div>  

            <div class="col-md-12 mb-3">
                  <label for="">Meta Title</label>
                  <input type="text" class="form-control" name="meta_title" value="<?php echo e($val->meta_title); ?>">
            </div>  

            <div class="col-md-12 mb-3">
                  <label for="">Meta Keywords</label>
                  <input type="text" class="form-control" name="meta_keywords" value="<?php echo e($val->meta_keywords); ?>">
            </div>  

     
            <div class="col-md-12 mb-3">
                  <label for="">Meta Description</label>
                  <textarea rows="3" class="form-control" name="meta_descript"><?php echo e($val->meta_descript); ?></textarea>
            </div>
            <div class="col-md-12">
                  <input type="file" name="image" class="form-control">
                  <img src="<?php echo e(asset('assets/uploads/product/'.$val->image)); ?>" style="max-width:70px;">
            </div>

      <div class="col-md-12">    
           <button type="submit" class="btn btn-primary">Submit</button>
      </div> 

        </div>
      </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\resources\views/admin/product/update.blade.php ENDPATH**/ ?>