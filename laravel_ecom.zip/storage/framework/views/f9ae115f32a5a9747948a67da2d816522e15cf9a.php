
<!--  CReate Modal -->
<div id="id01" class="w3-modal" style="padding-top:10px">
      <div class="w3-modal-content w3-animate-top w3-card-4" style="width:450px;">
      <header class="w3-container w3-teal"> 
        <span onclick="model_close()" class="w3-button w3-display-topright w3-large"><b>&times;</b></span>
      </header>
       
      
      <div class="w3-panel">
           <div class="w3-border w3-border-blue w3-round" style="max-width:400px;width:100%;margin-left:auto;margin-right:auto">
                              <div class="w3-container w3-blue">
                                    <h3> Create</h3>
                              </div>
                              <div class="w3-container">
      
                                
                                  <?php echo csrf_field(); ?>        
                              
                                  <h6>Name</h6>
                                  <input required type="text" id="name" name="name" class="w3-block w3-border w3-border-gray w3-round w3-large"><br>  
                                  
                                  
                                  
      
                                  <h6>Email</h6>
                                  <input required type="email" id="email" name="email" class="w3-block w3-border w3-border-gray w3-round w3-large"><br>  
                                  
                                    
                                  <h6>Phone</h6>
                                  <input required type="text" id="phone" name="phone" class="w3-block w3-border w3-border-gray w3-round w3-large"><br>  
                                  
                                  
                                    
                                  <h6>Description</h6>
                                  <textarea required type="text" id="description" name="description" class="w3-block w3-border w3-border-gray w3-round w3-large"></textarea><br>  
                                  
                                    
                        
                                  <h6>Image</h6>
                                  <input required type="file" id="image" name="image" class="w3-block w3-border w3-border-gray w3-round"><br>  
                                  
                                  
      
                                  <div class="w3-center w3-margin-top">
                                  <button onclick="create()" class="w3-button w3-red w3-round">Create</button>
                                  </div>
                                  <br>
                                 
                                   
                                
                              </div> 
      
                
                
                      </div>   
      
           </div><br>
      
      
      </div>
</div>

<?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\resources\views/admin/category/add_modal.blade.php ENDPATH**/ ?>