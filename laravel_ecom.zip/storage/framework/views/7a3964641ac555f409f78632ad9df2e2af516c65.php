<nav class="navbar navbar-expand-lg <?php echo e(App\Models\Setting::first()->nav_color); ?>">
      <div class="container">
        
        <a class="navbar-brand" href="<?php echo e(url('')); ?>">
          <img src="<?php echo e(asset('assets/setting/'.App\Models\Setting::first()->logo)); ?>" class="rounded" alt="Logo" width="70px">
          <?php echo e(App\Models\Setting::first()->name); ?>

        </a>

        <!-- Search box -->
         <div class="search-bar">
          <form action="<?php echo e(url('/search-product')); ?>" method="POST">
            <?php echo csrf_field(); ?>
          <div class="input-group">
            <input type="search" class="form-control" name="product_name" id="auto_complete" placeholder="Seach Product" aria-label="Username" aria-describedby="basic-addon1">          
            <button type="submit" class="input-group-text"><i class="fa fa-search"></i></button>
          </div>
          </form>
         </div>


        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link <?php echo e(Request::is('/') ? 'active':''); ?>" aria-current="page" href="<?php echo e(url('')); ?>">Home</a>
            </li>

            <li class="nav-item">
              <a class="nav-link <?php echo e(Request::is('category') ? 'active':''); ?>" href="<?php echo e(url('/category')); ?>">Category</a>
            </li>
            
            
            <?php if(Auth::user()): ?>
            <li class="nav-item">
              <a class="nav-link <?php echo e(Request::is('cart') ? 'active':''); ?>" href="<?php echo e(url('/cart')); ?>"><i class="fa fa-shopping-cart"></i> Cart
              <span class="badge badge-pill bg-primary cart-count">0</span>
              </a>
            </li>
            

            <li class="nav-item">
              <a class="nav-link <?php echo e(Request::is('wishlist') ? 'active':''); ?>" href="<?php echo e(url('/wishlist')); ?>"><i class="fa fa-wish-list"></i> Wishlist
                <span class="badge badge-pill bg-success wish-count">0</span>
              </a>
            </li>
            <?php endif; ?>
       


        <?php if(auth()->guard()->guest()): ?>
            <?php if(Route::has('login')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                </li>
            <?php endif; ?>

            <?php if(Route::has('register')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                </li>
            <?php endif; ?>
        <?php else: ?>
            <li class="nav-item dropdown">
                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <?php echo e(Auth::user()->name); ?>

                </a>

                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">

                    <a href="<?php echo e(url('/profile')); ?>" class="dropdown-item">Profile</a>
                    <a href="<?php echo e(url('/my-orders')); ?>" class="dropdown-item">My Orders</a>
                    


                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();">
                        <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </li>
        <?php endif; ?>
            






          </ul>
        </div>
      </div>
    </nav><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\resources\views/layouts/front_inc/front_navbar.blade.php ENDPATH**/ ?>