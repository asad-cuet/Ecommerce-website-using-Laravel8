<?php echo e($slot); ?>

<?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>