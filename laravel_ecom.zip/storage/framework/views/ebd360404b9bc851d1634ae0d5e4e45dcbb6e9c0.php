                                     <!-- showing main component  -->
   
<?php $__env->startSection('title'); ?>
All Categories
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

     

<div class="py-5">
      <div class="container">
            <div class="row">
                  <h2>All Categories</h2>
                  
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             
                              <div class="col-md-3 mb-3">
                                    <a href="<?php echo e(url('category/'.$item->slug)); ?>" >
                                    <div class="card">
                                          <img src="<?php echo e(asset('assets/uploads/category/'.$item->image)); ?>" alt="Product Image">
                                          <div class="card-body">
                                                <h5><?php echo e($item->name); ?></h5>
                                          </div>
                                    </div>
                                    </a>
                              </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
            </div>
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\resources\views/frontend/category.blade.php ENDPATH**/ ?>