                                     <!-- showing main component  -->
   
<?php $__env->startSection('title'); ?>
Checkout Page
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="container mt-5">
   <form action="<?php echo e(url('/place-order')); ?>" method="POST">
      <?php echo csrf_field(); ?>  
      <div class="row">
            <div class="col-md-5">
                  <div class="card">
                        <div class="card-body">
                              <h6>Basic Details</h6>
                              <hr>
                              <div class="row checkout-form">
                                    <div class="col-md-6">
                                          <label for="">First Name</label>
                                          <input required type="text" name="fname" value="<?php echo e(Auth::user()->fname); ?>" class="form-control fname" placeholder="Enter First Name">
                                          <span id="fname_error" class="text-danger"></span>
                                    </div>
                                    <div class="col-md-6">
                                          <label for="">Last Name</label>
                                          <input required type="text" name="lname" value="<?php echo e(Auth::user()->lname); ?>" class="form-control lname" placeholder="Enter Last Name">
                                          <span id="lname_error" class="text-danger"></span>
                                    </div>
                                    <div class="col-md-6 mt-3">
                                          <label for="">Email</label>
                                          <input required type="email" name="email" value="<?php echo e(Auth::user()->email); ?>" class="form-control email" placeholder="Enter Email">
                                          <span id="email_error" class="text-danger"></span>
                                    </div>
                                    <div class="col-md-6 mt-3">
                                          <label for="">Phone number</label>
                                          <input required type="text" name="phone" value="<?php echo e(Auth::user()->phone); ?>" class="form-control phone" placeholder="Enter Phone Number">
                                          <span id="phone_error" class="text-danger"></span>
                                    </div>
                                    <div class="col-md-6 mt-3">
                                          <label for="">Address 1</label>
                                          <input required type="text" name="address1" value="<?php echo e(Auth::user()->address1); ?>" class="form-control address1" placeholder="Enter Address 1">
                                          <span id="address1_error" class="text-danger"></span>
                                    </div>
                                    <div class="col-md-6 mt-3">
                                          <label for="">Address 2</label>
                                          <input type="text" name="address2" value="<?php echo e(Auth::user()->address2); ?>" class="form-control address2" placeholder="Enter Address 2">
                                          
                                    </div>
                                    <div class="col-md-6 mt-3">
                                          <label for="">City</label>
                                          <input required type="text" name="city" value="<?php echo e(Auth::user()->city); ?>" class="form-control city" placeholder="Enter City">
                                          <span id="city_error" class="text-danger"></span>
                                    </div>
                                    <div class="col-md-6 mt-3">
                                          <label for="">State</label>
                                          <input required type="text" name="state" value="<?php echo e(Auth::user()->state); ?>" class="form-control state" placeholder="Enter State">
                                          <span id="state_error" class="text-danger"></span>
                                    </div>
                                    <div class="col-md-6 mt-3">
                                          <label for="">Country</label>
                                          <input required type="text" name="country" value="<?php echo e(Auth::user()->country); ?>" class="form-control country" placeholder="Enter Country">
                                          <span id="country_error" class="text-danger"></span>
                                    </div>
                                    <div class="col-md-6 mt-3">
                                          <label for="">Post Code</label>
                                          <input required type="password" name="pincode" value="<?php echo e(Auth::user()->pincode); ?>" class="form-control pincode" placeholder="Enter Pin Code">
                                          <span id="pincode_error" class="text-danger"></span>
                                    </div>
                              </div>
                        </div>
                  </div>
            </div>
            <div class="col-md-7">
                  <div class="card">
                        <div class="card-body">
                              <?php if($cartitems->count()>0): ?>
                              Order Details
                              <hr>
                              <table class="table table-striped table-bordered">
                                    <thead>
                                          <tr>
                                                <th>Image</th>
                                                <th>Name</th>
                                                <th>Qty</th>
                                                <th>Price</th>
                                          </tr>
                                    </thead>
                                    <tbody>
                                          <?php $total=0; ?>
                                          <?php $__currentLoopData = $cartitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <tr>
                                                    <td>
                                                            <img src="<?php echo e(asset('assets/uploads/product/'.$item->product->image)); ?>" width="50px" alt="Product Image">
                                                    </td>
                                                    <td><?php echo e($item->product->name); ?></td>
                                                    <td><?php echo e($item->prod_qty); ?></td>
                                                    <td><?php echo e($item->product->selling_price); ?></td>
                                              </tr>
                                          <?php $total+=($item->product->selling_price)*($item->prod_qty); ?>    
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                              </table>
                              <h4>Total : <span class="float-end">$ <?php echo e($total); ?></span></h4>
                              <hr>
                              <input type="hidden" class="total" value="<?php echo e($total); ?>">
                              <input type="hidden" name="payment_mode" value="COD">
                              <button type="submit" class="btn btn-success w-100">Place Order | Cash On Delivery</button>
                              <button type="button" class="btn btn-primary w-100 mt-3 razorpay_btn">Pay with Razorpay</button>
                              
                              <!-- paypal button -->
                              <div class="mt-3">
                                    <div id="paypal-button-container"></div>
                              </div>
                              

                              <?php else: ?>
                                  <h4 class="text-center">No products in Cart</h4>

                              <?php endif; ?>
                        </div>
                  </div>
            </div>
      </div> 
   </form>   
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- paypal script -->
<script src="https://www.paypal.com/sdk/js?client-id=AQHZPWmsg8QTiAx6bgfd6QXE-PSxVJKJy4Y70K91GMbKlTm2IgLpffo0gYtUnuSLy7iDLWzF_GBRZC_6&currency=USD"></script>
<script src="js/paypal.js"></script>
<!-- razorpay script -->
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>






<!-- SSL -->





 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\resources\views/frontend/checkout.blade.php ENDPATH**/ ?>